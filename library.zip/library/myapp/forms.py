from django import forms
from .models import *

class DateInput(forms.DateInput):
    input_type = 'date'


class PatientsForm(forms.Form):
    patientid = forms.IntegerField()
    patientname = forms.CharField(widget=forms.TextInput(attrs={'placeholder':'Enter Name','required':'1'}))
    email = forms.EmailField(widget=forms.EmailInput(attrs={'placeholder':'Enter Email','required':'1'}))
    Pwd = forms.CharField(widget=forms.PasswordInput(attrs={'placeholder':'Enter Password','required':'1'}))
    phone = forms.CharField()
    address = forms.CharField()
    sex = forms.ChoiceField(choices=[('MALE','M'),('FEMALE','F'),('THIRD','T')])
    bdate = forms.DateField(widget=DateInput)
    age = forms.CharField()
    blood = forms.ChoiceField(choices=[('Aplus','Aplus'),('Aminus','Aminus'),('Bplus','Bplus'),('Bminus','Bminus'),('ABplus','ABplus'),('ABminus','ABminus'),('Oplus','Oplus'),('Ominus','Ominus')])
    class Meta:
        model = Patient()
        fields = ['patientid','patientid','email','pwd','phone','address','sex','bdate','age','blood']
        

 