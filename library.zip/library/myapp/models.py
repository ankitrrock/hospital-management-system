from django.db import models

# Create your models here.
class Department(models.Model):
    deptId=models.CharField(max_length=10,null=True,blank=True)
    deptName=models.CharField(max_length=20,null=True,blank=True)
    deptDesc=models.CharField(max_length=50,null=True,blank=True)

class Doctor(models.Model):
    doctid=models.CharField(max_length=10,null=True,blank=True)
    doctname=models.CharField(max_length=10,null=True,blank=True)
    email=models.CharField(max_length=10,null=True,blank=True)
    pwd=models.CharField(max_length=10,null=True,blank=True)
    add=models.CharField(max_length=10,null=True,blank=True)
    phone=models.CharField(max_length=10,null=True,blank=True)
    deptId=models.models.ForeignKey("deptName", on_delete=models.CASCADE)

