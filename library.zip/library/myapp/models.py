from django.db import models
from datetime import date


# Create your models here.
class Department(models.Model):
    deptId=models.CharField(max_length=10,null=True,blank=True)
    deptName=models.CharField(max_length=20,null=True,blank=True)
    deptDesc=models.CharField(max_length=50,null=True,blank=True)
    

class Doctor(models.Model):
    docid=models.IntegerField(null=True,blank=True)
    dacname=models.CharField(max_length=10,null=True,blank=True)
    email=models.EmailField(null=True,blank=True)
    Pwd=models.CharField(max_length=10,null=True,blank=True)
    phone=models.CharField(max_length=10,null=True,blank=True)

class Nurse(models.Model):
    nid=models.IntegerField(null=True,blank=True)
    name=models.CharField(max_length=20,null=True,blank=True)
    email=models.EmailField(null=True,blank=True)
    password=models.CharField(max_length=20,null=True,blank=True)
    phone=models.CharField(max_length=20,null=True,blank=True)
    address=models.CharField(max_length=50,null=True,blank=True)

class Patient(models.Model):
    MALE = 'M'
    FEMALE = 'F'
    THIRD = 'T'
    Aplus = 'Aplus'
    Aminus = 'Aminus'
    Bplus = 'Bplus'
    Bminus = 'Bminus'
    ABplus = 'ABplus'
    ABminus = 'ABminus'
    Oplus = 'Oplus'
    Ominus = 'Ominus'
    patientid=models.IntegerField(null=True,blank=True)
    patientname=models.CharField(max_length=20,null=True,blank=True)
    email=models.EmailField(null=True,blank=True)
    Pwd=models.CharField(max_length=10,null=True,blank=True)
    phone=models.CharField(max_length=15,null=True,blank=True)
    address=models.CharField(max_length=50,null=True,blank=True)
    SEX=[
        (MALE,'M'),
        (FEMALE,'F'),
        (THIRD,'T')
        ]
    sex=models.CharField(max_length=10,choices=SEX,default=MALE)
    bdate=models.DateField(auto_now=False,default=date.today)
    age=models.CharField(max_length=3,null=True,blank=True,)
    BLOODGROUP=[
        (Aplus,'Aplus'),
        (Aminus,'Aminus'),
        (Bplus,'Bplus'),
        (Bminus,'Bminus'),
        (ABplus,'ABplus'),
        (ABminus,'ABminus'),
        (Oplus,'Oplus'),
        (Ominus,'Ominus')
        ]
    blood=models.CharField(max_length=10,choices=BLOODGROUP,default=Aplus)
    