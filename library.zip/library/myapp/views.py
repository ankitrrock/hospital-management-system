from django.shortcuts import render
from django.http import HttpResponse
from .models import Department
from django.template import loader
from django.contrib.auth.models import User,auth
from django.contrib import messages

# Create your views here.
def index(request):
    return render(request,"index.html")

def department(request):
    ''''
    Here is your initial code.There are a few notable errors.One of them is
    passing of the context to the return value from the view function.You have written it Department instead of the
    object from the database which is Department_datas;
    The first parameter of the dictionary is the name that you will use in your template when looping
    through the data.
    Naming convention is also very important when developing applications .Object name should be written in small letters
    i.e Department_datas should be department_datas;
    ****HERE IS YOUR CODE****
    Department_datas = Department.objects.all()

    return render(request,"department.html",{'Department_datas':Department})
    ****END OF YOUR CODE****
    Below is the correct implimentation of the problem.
    Mark the second argument of the dictionary.

    '''
    department_datas = Department.objects.all()

    return render(request, "department.html", {'department_datas': department_datas})



def doctor(request):
    return render(request,"doctor.html")

def nurse(request):
    return render(request,"nurse.html")

def patients(request):
    return render(request,"patients.html")

def profile(request):
    return render(request,"profile.html")

def header(request):
    return render(request,"header.html")

def add_department(request):
    department_detail= Department()
    if request.method == 'POST':
        department_detail.deptId = request.POST["deptId"]
        department_detail.deptName = request.POST["deptName"]
        department_detail.deptDesc = request.POST["deptDesc"]
        department_detail.save()
        return render(request,"department.html")
    else:
        return render (request,"department.html")
       

