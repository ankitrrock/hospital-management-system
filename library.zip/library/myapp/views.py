from django.shortcuts import render
from django.http import HttpResponse
from .models import *
from django.template import loader
from django.contrib.auth.models import User,auth
from django.contrib import messages
from .forms import *

# Create your views here.
def index(request):
    return render(request,"index.html")

def department(request):
    department_datas = Department.objects.all()
    return render(request, "department.html", {'department_datas': department_datas})


def doctor(request):
    data=Doctor.objects.all()
    return render(request,"doctor.html",{'data':data})

def nurse(request):
    data=Nurse.objects.all() 
    return render(request,"nurse.html",{'data':data})

def patients(request):
    data=Patient.objects.all()
    s_form = PatientsForm()
    add_patients=Patient()
    if request.method == "POST":
        s_form= PatientsForm(request.POST)
        if s_form.is_valid():
            data = s_form.cleaned_data
            patient = Patient()
            Patient.objects.create(patientid=data['patientid'],email=data['email'],patientname=data['patientname'],Pwd=data['Pwd'],phone=data['phone'],address=data['address'],sex=data['sex'],bdate=data['bdate'],age=data['age'],blood=data['blood'])
            patient.save()
            return render(request,'patients.html',{'s_form':s_form})
    return render(request,"patients.html",{'data':data,'s_form':s_form})

def profile(request):
    return render(request,"profile.html")

def header(request):
    return render(request,"header.html")

def add_department(request):
    department_detail = Department()
    if request.method == 'POST':
        department_detail.deptId = request.POST["deptId"]
        department_detail.deptName = request.POST["deptName"]
        department_detail.deptDesc = request.POST["deptDesc"]

        department_detail.save()
        messages.success(request,'Department added successfully')
        return render(request,"department.html")
    else:
        return render(request,"department.htm")

def add_doctor(request):
    add_doctor=Doctor()
    if request.method == 'POST':
        add_doctor.docid = IntegerField.POST["docid"]
        add_doctor.dacname = CharField.POST["dacname"]
        add_doctor.email = EmailField.POST["email"]
        add_doctor.Pwd = Charfield.POST["pwd"]
        add_doctor.phone = IntegerField["phone"]
        add_doctor.save()
        messages.success(request,'Doctor added successfully')
        return render(request,"doctor.html")
    else:
        return render(request,"doctor.html")

def add_nurse(request):
    add_nurse=Nurse()
    if request.method == 'POST':
        add_nurse.nid = IntegerField.POST["nid"]
        add_nurse.name = CharField.POST["name"]
        add_nurse.email = EmailField.post["email"]
        add_nurse.password = CharField.POST["password"]
        add_nurse.phone = IntegerField.POST["phone"]
        add_nurse.address =CharField.POST["address"]
        messages.success(request,'nurse added successfully')
        return render(request,"nurse.html")
    else:
        return render(request,"nurse.html")



