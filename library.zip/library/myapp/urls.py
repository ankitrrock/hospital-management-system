from django.urls import path
from myapp import views




urlpatterns = [
    path("",views.index, name="index"),
    path("department",views.department,name="department"),
    path("doctor",views.doctor,name="doctor"),
    path("nurse",views.nurse,name="nurse"),
    path("patients",views.patients,name="patients"),
    path("profile",views.profile,name="profile"),
    path("header",views.profile,name="header"),   
    path("add_department",views.department,name="add_department")
]

