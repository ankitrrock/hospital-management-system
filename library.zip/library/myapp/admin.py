from django.contrib import admin
from.models import Department,Doctor,Patient,Nurse

# Register your models here.
admin.site.register(Department)
admin.site.register(Patient)
admin.site.register(Nurse)
admin.site.register(Doctor)

